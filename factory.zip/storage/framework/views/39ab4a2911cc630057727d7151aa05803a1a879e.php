<?php echo $__env->make('client.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content">
    <div class="p-4">
        <a href="<?php echo e(route('category.add')); ?>" class="normal_button">إضافة جديد</a>
    </div>
    
    <div class="tab_cover my-8">
        <ul class="tab_ul">
            <li class="mr-2">
                <a href="<?php echo e(route('category.home')); ?>" class="selected_tab">الانشطة</a>
            </li>                
            <li class="mr-2">
                <a href="<?php echo e(route('neighborhood.home')); ?>" class="unselected_tab">الأحياء</a>
            </li>                           
        </ul>
    </div>
    
    <div class="flex flex-col">
        <div class="overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div class="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                <div class="overflow-x-auto">
                    <table class="w-full px-6 text-sm text-center text-gray-500 dark:text-gray-400">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-200 dark:bg-gray-300 dark:text-gray-800">
                            <tr>
                                <th scope="col" class="px-6 py-3">#</th>
                                <th scope="col" class="px-6 py-3">الاسم</th>
                                <th scope="col" class="px-6 py-3">حذف / تعديل</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                
                                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">                                                                                                
                                    <th scope="row"><?php echo e($category->id); ?></th>
                                    <td class="px-6 py-2"><?php echo e($category->name); ?></td>                                    
                                    <td class="px-6 py-2"><a href="<?php echo e(route('category.edit')); ?>?id=<?php echo e($category->id); ?>"  class="text-red-800 font-extrabold hover:underline">تعديل</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php echo e($categories->links('pagination::bootstrap-4')); ?>

    <!-- </div> -->
</div>

<?php echo $__env->make('client.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sites\factory\resources\views/categories/home.blade.php ENDPATH**/ ?>