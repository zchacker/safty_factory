<?php echo $__env->make('client.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content">
    <h1 class="text-xl font-bold mb-8">إضافة حي جديد</h1>
    <div class="w-full my-2">
        <?php if(strlen($error_message) > 0): ?>
        <div class="danger" role="alert">
            <?php echo $error_message; ?>

        </div>
        <?php endif; ?>

        <?php if(strlen($message) > 0): ?>
        <div class="success" role="alert">
            <?php echo e($message); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="relative overflow-x-clip mt-6">        
        <form action="" method="post" class="relative">
            <?php echo csrf_field(); ?>            
            <div class="relative z-0 w-full mb-6 group">
                <input type="text"id="name" name="name" class="input_box peer" value="<?php echo e(old('name')); ?>" placeholder="" required />
                <label for="name" class="lable_box">اكتب اسم الحي</label>
            </div>            
            
            <div class="relative z-0 w-full mb-6 group">
                <input type="submit" value="حفظ" class="normal_button" />
                <a href="<?php echo e(route('neighborhood.home')); ?>" class="cancel_button">إلغاء</a>
            </div>
        </form>
    </div>
</div>


<?php echo $__env->make('client.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sites\factory\resources\views/neighborhoods/add.blade.php ENDPATH**/ ?>