        </div>
    </body>
</html><?php /**PATH C:\wamp64\www\sites\factory\resources\views/client/footer.blade.php ENDPATH**/ ?>