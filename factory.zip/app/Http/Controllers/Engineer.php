<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Engineer extends Controller
{
    //

    public function Home(Request $request)
    {
        return "Hello";
    }
}
